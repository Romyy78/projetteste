#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_ROWS 10
#define MAX_COLS 10

void generateGrid(int rows, int cols) {
    char grid[MAX_ROWS][MAX_COLS];
    char symbols[] = {'A', 'B', 'C', 'D', 'E', 'F'};
    int num_symbols = rand() % 3 + 4;  // Nombre de symboles entre 4 et 6
    int num_consecutive = 0;

    // Initialisation de la grille avec des symboles aléatoires
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int random_symbol = rand() % num_symbols;
            grid[i][j] = symbols[random_symbol];
        }
    }

    // Vérification et remplacement des symboles consécutifs
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (j >= 2 && grid[i][j] == grid[i][j - 1] && grid[i][j] == grid[i][j - 2]) {
                // Remplacer le symbole répété par un symbole différent
                int random_symbol = rand() % num_symbols;
                while (symbols[random_symbol] == grid[i][j]) {
                    random_symbol = rand() % num_symbols;
                }
                grid[i][j] = symbols[random_symbol];
            }
            if (i >= 2 && grid[i][j] == grid[i - 1][j] && grid[i][j] == grid[i - 2][j]) {
                // Remplacer le symbole répété par un symbole différent
                int random_symbol = rand() % num_symbols;
                while (symbols[random_symbol] == grid[i][j]) {
                    random_symbol = rand() % num_symbols;
                }
                grid[i][j] = symbols[random_symbol];
            }
        }
    }

    // Affichage de la grille
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }
}

int main() {
    srand(time(0));  // Initialiser la graine du générateur de nombres aléatoires

    int rows, cols;

    printf("Entrez le nombre de lignes de la grille : ");
    scanf("%d", &rows);

    printf("Entrez le nombre de colonnes de la grille : ");
    scanf("%d", &cols);

    generateGrid(rows, cols);

    return 0;
}