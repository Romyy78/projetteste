#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_M 10
#define MAX_N 10
#define MIN_SYMBOLS 4
#define MAX_SYMBOLS 6

// Fonction pour générer un entier aléatoire entre min et max (inclus)
int aleatoire(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Fonction pour générer la grille avec les conditions requises
void generateGrid(int M, int N) {
    char grid[MAX_M][MAX_N];
    int i, j;

    // Demander à l'utilisateur de saisir les symboles
    char symbols[MAX_SYMBOLS];
    int numSymbols;

    printf("Combien de symboles différents souhaitez-vous utiliser (entre %d et %d) ? ", MIN_SYMBOLS, MAX_SYMBOLS);
    scanf("%d", &numSymbols);

    printf("Saisissez les symboles un par un :\n");
    for (i = 0; i < numSymbols; i++) {
        printf("Symbole %d : ", i + 1);
        scanf(" %c", &symbols[i]);
    }

    // Génération de la grille
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            // Vérification des symboles voisins
            char symbol;
            do {
                symbol = symbols[aleatoire(0, numSymbols - 1)];
            } while ((i > 1 && grid[i-1][j] == symbol && grid[i-2][j] == symbol) ||
                     (j > 1 && grid[i][j-1] == symbol && grid[i][j-2] == symbol));

            // Placement du symbole dans la grille
            grid[i][j] = symbol;
        }
    }

    // Affichage de la grille générée
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int M, N;

    srand(time(NULL));

    printf("Entrez le nombre de lignes (M) : ");
    scanf("%d", &M);
    printf("Entrez le nombre de colonnes (N) : ");
    scanf("%d", &N);

    generateGrid(M, N);

    return 0;
}

