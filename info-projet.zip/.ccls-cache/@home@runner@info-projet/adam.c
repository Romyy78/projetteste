#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_M 10
#define MAX_N 10
#define MIN_SYMBOLS 4
#define MAX_SYMBOLS 6

// Fonction pour générer un entier aléatoire entre min et max (inclus)
int aleatoire(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Fonction pour générer la grille avec les conditions requises
void grille(int M, int N) {
    char grid[MAX_M][MAX_N];
    int i, j;

    // Tableau de symboles possibles
    char symboles[] = {'A', 'B', 'C', 'D', 'E', 'F'};
    int numSymbols = aleatoire(MIN_SYMBOLS, MAX_SYMBOLS);

    // Mélange des symboles
    for (i = 0; i < numSymbols; i++) {
        int randomIndex = aleatoire(i, numSymbols - 1);
        char temp = symboles[i];
        symboles[i] = symboles[randomIndex];
        symboles[randomIndex] = temp;
    }

    // Génération de la grille
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            // Vérification des symboles voisins
            char symbol;
            do {
                symbol = symboles[aleatoire(0, numSymbols - 1)];
            } while ((i > 1 && grid[i-1][j] == symbol && grid[i-2][j] == symbol) ||
                     (j > 1 && grid[i][j-1] == symbol && grid[i][j-2] == symbol));

            // Placement du symbole dans la grille
            grid[i][j] = symbol;
        }
    }

    // Affichage de la grille générée
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int M, N;

    srand(time(NULL));

    printf("Entrez le nombre de lignes (M) : ");
    scanf("%d", &M);
    printf("Entrez le nombre de colonnes (N) : ");
    scanf("%d", &N);

    grille(M, N);

    return 0;
}
