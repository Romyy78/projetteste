void afficher_menu();

void init_board();

void print_board();

int is_valid_move(int x1, int y1, int x2, int y2);

int remove_matches();

void apply_gravity();

int play_game();
