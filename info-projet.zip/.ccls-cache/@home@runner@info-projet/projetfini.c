

#include <stdio.h>   
#include <stdlib.h>
#include <time.h>
#include <ctype.h>


#define BOARD_SIZE 10

char board[BOARD_SIZE][BOARD_SIZE];

void init_board() {
    int i, j;
    char tiles[] = {'U', 'X', 'I', 'O'};
    srand(time(NULL));
    for (i = 0; i < BOARD_SIZE; i++) {
        for (j = 0; j < BOARD_SIZE; j++) {
            int random_index = rand() % (sizeof(tiles) / sizeof(char));
            board[i][j] = tiles[random_index];
        }
    }
}

// bloc de code pour print en couleur en fonction des symboles de la grille
void print_board() {
    printf("    ");
    for (int col = 0; col < BOARD_SIZE; col++) {
        printf(" %c", 'A' + col);
    }
    printf("\n");
    printf("    ");
        for (int col = 0; col < BOARD_SIZE; col++) {
        printf(" -");
    }
    printf("\n");
    for (int row = 0; row < BOARD_SIZE; row++) {
        printf("%2d |", row + 1);
        for (int col = 0; col < BOARD_SIZE; col++) {
                    switch (board[row][col]) {
                        case 'U':
                            printf("\033[0;31m"); // red
                            break;
                        case 'X':
                            printf("\033[0;34m"); // blue
                            break;
                        case 'I':
                            printf("\033[0;32m"); // green
                            break;
                        case 'O':
                            printf("\033[0;33m"); // orange
                            break;
                    }
                    printf(" %c\033[0m", board[row][col]); // reset color
                }
        printf("\n");
    }
}

// SERT A ACCEPTER L ECHANGE ENTRE 2 SYMBOLE COTE A COTE ET REFUSER SI CEST ELOIGNER
int is_valid_move(int x1, int y1, int x2, int y2) {
    if (x1 < 0 || x1 >= BOARD_SIZE || y1 < 0 || y1 >= BOARD_SIZE ||
        x2 < 0 || x2 >= BOARD_SIZE || y2 < 0 || y2 >= BOARD_SIZE ||
        (x1 != x2 && y1 != y2) || abs(x1 - x2) > 1 || abs(y1 - y2) > 1) {
        return 0;
    }
    return 1;
}

      // pas compris
int is_match(int x, int y, int dx, int dy) {
    char symbol = board[x][y];
    int count = 0;
    while (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE && board[x][y] == symbol) {
        count++;
        x += dx;
        y += dy;
    }
    return count >= 3;
}

int remove_matches() {
    int i, j, k;
    int removed = 0;
    for (i = 0; i < BOARD_SIZE; i++) {
        for (j = 0; j < BOARD_SIZE; j++) {
            if (board[i][j] != ' ') {
                for (k = -1; k <= 1; k++) {
                    if (is_match(i, j, 1, k) || is_match(i, j, k, 1) || is_match(i, j, 1, 1) || is_match(i, j, -1, 1)) {
                        board[i][j] = ' ';
                        removed++;
                        break;
                    }
                }
            }
        }
    }
    return removed;
}
// CE BLOC FAIT DE
void apply_gravity() {
    int i, j, k;
    for (j = 0; j < BOARD_SIZE; j++) {
        k = BOARD_SIZE - 1;
        for (i = BOARD_SIZE - 1; i >= 0; i--) {
            if (board[i][j] != ' ') {
                board[k][j] = board[i][j];
                k--;
            }
        }
        for (; k >= 0; k--) {
            board[k][j] = ' ';
        }
    }
}

int play_game() {
    int score = 0;
    init_board();
    while (1) {
        printf("Score: %d\n", score);
        print_board();
        printf("Quelles cases voulez vous déplacer ? (ex. A1 B2): ");
        char col1, col2;
        int row1, row2;
        scanf(" %c%d %c%d", &col1, &row1, &col2, &row2);
        col1 = toupper(col1);
        col2 = toupper(col2);
        int x1 = row1 - 1;
        int y1 = col1 - 'A';
        int x2 = row2 - 1;
        int y2 = col2 - 'A';
        if (!is_valid_move(x1, y1, x2, y2)) {
            printf("Mouvement non valide\n");
            continue;
        }
        char temp = board[x1][y1];
        board[x1][y1] = board[x2][y2];
        board[x2][y2] = temp;
        int removed = remove_matches();
        while (removed) {
            score += removed;
            apply_gravity();
            remove_matches();
            print_board();
            printf("Score: %d\n", score);
            printf("Correspondances supprimees: %d\n", removed);
            removed = remove_matches();
        }
    }
    return score;
}

int main() {
    int score = play_game();
    printf("Score final: %d\n", score);
    return 0;
}
