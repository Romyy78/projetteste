#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define MAX_LIGNE 10
#define MAX_COLONE 10
#define MIN_SYMBOLE 4
#define MAX_SYMBOLE 6

// Fonction pour générer un entier aléatoire entre min et max (inclus)
int aleatoire(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Fonction pour générer la grille avec les conditions requises
void generer_grille(char grille[MAX_LIGNE][MAX_COLONE], int M, int N) {
    int i, j;

    char tableau_symbole[] = {'A', 'B', 'C', 'D', 'E', 'F'};
    int nombre_symbole;

    // Demande à l'utilisateur de choisir le nombre de symboles différents
    do {
        printf("Combien de symboles différents souhaitez-vous utiliser (entre 4 et 6) ? ");
        scanf("%d", &nombre_symbole);
    } while (nombre_symbole > 6 || nombre_symbole < 4);

    // Génération de la grille
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            char symbole;
            do {
                symbole = tableau_symbole[aleatoire(0, nombre_symbole - 1)];
            } while ((i > 1 && grille[i-1][j] == symbole && grille[i-2][j] == symbole) ||
                     (j > 1 && grille[i][j-1] == symbole && grille[i][j-2] == symbole));
            grille[i][j] = symbole;
        }
    }

    // Affichage de la grille générée
    printf("Grille générée :\n");
    for (i = 0; i < M; i++) {
        for (j = 0; j < N; j++) {
            printf("%c ", grille[i][j]);
        }
        printf("\n");
    }
}

void echangerValeurs(char tableau[MAX_LIGNE][MAX_COLONE], int ligne1, int col1, int ligne2, int col2) {
    char temp = tableau[ligne1][col1];
    tableau[ligne1][col1] = tableau[ligne2][col2];
    tableau[ligne2][col2] = temp;
}

int main() {
    int M, N;

    srand(time(NULL));

    // Demande à l'utilisateur de choisir le nombre de lignes et de colonnes
    do {
        printf("Entrez le nombre de lignes (M) inférieur à 10 et supérieur à 3 : ");
        scanf("%d", &M);
    } while (M > 10 || M < 3);
    do {
        printf("Entrez le nombre de colonnes (N) inférieur à 10 et supérieur à 3 : ");
        scanf("%d", &N);
    } while (N > 10 || N < 3);

char grille[MAX_LIGNE][MAX_COLONE];
generer_grille(grille, M, N);

// Demande à l'utilisateur de choisir les cases à échanger
int ligne1, col1, ligne2, col2;
printf("Entrez les coordonnées de la première case à échanger (ligne colonne) : ");
scanf("%d %d", &ligne1-, &col1-1);
printf("Entrez les coordonnées de la deuxième case à échanger (ligne colonne) : ");
scanf("%d %d", &ligne2-1, &col2-1);

if (ligne1 < 0 || ligne1 >= M || col1 < 0 || col1 >= N || ligne2 < 0 || ligne2 >= M || col2 < 0 || col2 >= N) {
    printf("Coordonnées invalides !\n");
    return 1;
}

// Appel de la fonction pour échanger les valeurs des cases
echangerValeurs(grille, ligne1, col1, ligne2, col2);

printf("\nAprès l'échange des cases :\n");
for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
        printf("%c ", grille[i][j]);
    }
    printf("\n");
}

return 0;

  }